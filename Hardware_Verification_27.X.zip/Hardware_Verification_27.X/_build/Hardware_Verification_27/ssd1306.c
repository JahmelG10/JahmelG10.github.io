/*
 * File:   newmain.c
 * Author: Garduno
 *
 * Created on April 28, 2025, 1:00 PM
 */


#include <xc.h>

void main(void) {
    return;
}
