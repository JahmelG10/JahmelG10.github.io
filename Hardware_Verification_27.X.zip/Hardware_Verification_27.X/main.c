#include "mcc_generated_files/system/system.h"

#define MSG_PREFIX_1     0x41
#define MSG_PREFIX_2     0x5A
#define MSG_SUFFIX_1     0x59
#define MSG_SUFFIX_2     0x42
#define MSG_TOTAL_LEN     64
#define MSG_MAX_LEN       64 // Maximum message length
#define HMI_ID            0x02 // Updated HMI ID

static volatile uint8_t msg_buffer[MSG_TOTAL_LEN];
static volatile uint8_t byte_count = 0;
static volatile bool msg_ready = false;

static volatile uint8_t uart_buffer[MSG_MAX_LEN];
static volatile uint8_t uart_index = 0;
static volatile bool message_ready = false;

void HandleFullMessage(uint8_t* buffer);
void ProcessMessage(const uint8_t* message);
void SendFanSpeedMessage(uint8_t fan_speed);
void CheckButtonAndSendFanSpeed(void);
void BlinkIO_RA7Twice(void);
void SendFanSpeedBroadcast(uint8_t speed);
void BlinkIO_RB4Twice(void);
void BlinkIO_RB3Twice(void);
void BlinkIO_RC0Twice(void);
void SendFanSpeedToWiFi(uint8_t speed);

// Define the UART ISR handler
void UART1_ISRHandler(uint8_t rxByte)
{
    // Check for message start (prefix)
    if (uart_index == 0 && rxByte == 0x41) // Prefix 1
    {
        uart_buffer[uart_index++] = rxByte;
    }
    else if (uart_index == 1 && rxByte == 0x5A) // Prefix 2
    {
        uart_buffer[uart_index++] = rxByte;
    }
    else if (uart_index >= 2 && uart_index < MSG_MAX_LEN)
    {
        uart_buffer[uart_index++] = rxByte;

        // Check for message end (suffix)
        if (uart_index == MSG_MAX_LEN &&
            uart_buffer[62] == 0x59 && // Suffix 1
            uart_buffer[63] == 0x42)  // Suffix 2
        {
            message_ready = true; // Mark message as ready
            uart_index = 0;       // Reset buffer index for the next message
        }
    }
    else
    {
        uart_index = 0; // Reset if something goes wrong
    }
}

void HandleFullMessage(uint8_t* buffer)
{
    // Now the full 64-byte message is available
    ProcessMessage(buffer);
}

void ProcessMessage(const uint8_t* message)
{
    // Extract message fields
    uint8_t source_id = message[2];
    uint8_t destination_id = message[3];
    uint8_t message_type = message[4];

    // Validate the message
    if (message[0] != 0x41 || message[1] != 0x5A || // Prefix
        message[62] != 0x59 || message[63] != 0x42) // Suffix
    {
        return; // Invalid message format
    }

    // Light up IO_RC5 to indicate a message was received
    IO_RC5_SetHigh(); // Turn on the pin
    __delay_ms(100);  // Keep it on for 100ms
    IO_RC5_SetLow();  // Turn off the pin

    // Check if the destination ID is valid
    if (destination_id != 0x01 && // wifi
        destination_id != 0x02 && // hmi
        destination_id != 0x03 && // dan
        destination_id != 0x58)   // broadcast
    {
        return; // Ignore the message if the destination ID is invalid
    }

    // If the message is designated for 0x03 (Dan), turn on IO_RB5 for 1 second
    if (destination_id == 0x03)
    {
        IO_RB5_SetHigh(); // Turn on the pin
        __delay_ms(1000); // Keep it on for 1 second
        IO_RB5_SetLow();  // Turn off the pin
    }

    // If the message is designated for 0x03 (Dan), turn on IO_RA6 for 1 second
    if (destination_id == 0x03)
    {
        IO_RA6_SetHigh(); // Turn on the pin
        __delay_ms(1000); // Keep it on for 1 second
        IO_RA6_SetLow();  // Turn off the pin
    }

    // Handle temperature messages (Message Type = 0x10)
    if (message_type == 0x10)
    {
        int8_t temp_data = (int8_t)message[7]; // Signed temperature data

        // Static variables to track the state of each LED
        static bool rb4_on = false; // For 20-25°C
        static bool rb3_on = false; // For 26-30°C
        static bool rc0_on = false; // For 31°C and above

        // Check if the temperature is between 20°C and 25°C
        if (temp_data >= 20 && temp_data <= 25)
        {
            if (!rb4_on)
            {
                IO_RB4_SetHigh(); // Turn on the LED
                rb4_on = true;
            }
        }
        else
        {
            if (rb4_on)
            {
                IO_RB4_SetLow(); // Turn off the LED
                rb4_on = false;
            }
        }

        // Check if the temperature is between 26°C and 30°C
        if (temp_data >= 26 && temp_data <= 30)
        {
            if (!rb3_on)
            {
                IO_RB3_SetHigh(); // Turn on the LED
                rb3_on = true;
            }
        }
        else
        {
            if (rb3_on)
            {
                IO_RB3_SetLow(); // Turn off the LED
                rb3_on = false;
            }
        }

        // Check if the temperature is 31°C or higher
        if (temp_data >= 31)
        {
            if (!rc0_on)
            {
                IO_RC0_SetHigh(); // Turn on the LED
                rc0_on = true;
            }
        }
        else
        {
            if (rc0_on)
            {
                IO_RC0_SetLow(); // Turn off the LED
                rc0_on = false;
            }
        }
    }

    // Check if the message is not for HMI (0x02) or broadcast (0x58)
    if (destination_id != HMI_ID && destination_id != 0x58)
    {
        // Indicate that the message is being forwarded
        IO_RA7_SetHigh(); // Turn on the LED
        __delay_ms(100);  // Keep it on for 100ms
        IO_RA7_SetLow();  // Turn off the LED

        // Pass the message along unchanged
        for (uint8_t i = 0; i < 64; i++)
        {
            while (!EUSART1_IsTxReady());
            EUSART1_Write(message[i]);
        }
        return; // Exit after forwarding the message
    }

    // Prepare a response message
    uint8_t response[64] = {0};
    response[0] = 'A'; // Prefix 1
    response[1] = 'Z'; // Prefix 2
    response[2] = destination_id; // Source becomes destination
    response[3] = source_id;      // Destination becomes source
    response[4] = message_type;   // Echo the message type

    // Copy the payload (bytes 5 to 61)
    for (uint8_t i = 5; i < 62; i++)
    {
        response[i] = message[i];
    }

    response[62] = 'Y'; // Suffix 1
    response[63] = 'B'; // Suffix 2

    // Send the response message
    for (uint8_t i = 0; i < 64; i++)
    {
        while (!EUSART1_IsTxReady());
        EUSART1_Write(response[i]);
    }
}

void SendFanSpeedMessage(uint8_t fan_speed)
{
    uint8_t message[64] = {0};

    // Construct the message
    message[0] = MSG_PREFIX_1; // Prefix 1
    message[1] = MSG_PREFIX_2; // Prefix 2
    message[2] = HMI_ID;       // Source ID (HMI)
    message[3] = 0x01;         // Destination ID (WiFi)
    message[4] = 0x20;         // Message Type (Fan Control)
    message[5] = 0x01;         // Fan ID (example: Fan 1)
    message[6] = 0x01;         // Status (1 = ON)
    message[7] = fan_speed;    // Fan Speed Data
    message[8] = fan_speed;    // Fan Speed Set
    // Remaining bytes are already initialized to 0
    message[62] = MSG_SUFFIX_1; // Suffix 1
    message[63] = MSG_SUFFIX_2; // Suffix 2

    // Send the message
    for (uint8_t i = 0; i < 64; i++)
    {
        while (!EUSART1_IsTxReady());
        EUSART1_Write(message[i]);
    }
}

void SendFanSpeedBroadcast(uint8_t speed)
{
    uint8_t msg[64] = {0};

    msg[0] = MSG_PREFIX_1;
    msg[1] = MSG_PREFIX_2;
    msg[2] = HMI_ID;
    msg[3] = 0x58;           // Broadcast ID
    msg[4] = 0x20;           // Fan Control message type
    msg[5] = 0x01;           // Fan ID
    msg[6] = 0x01;           // Status
    msg[7] = speed;          // Fan speed data
    msg[8] = speed;          // Fan speed set
    msg[62] = MSG_SUFFIX_1;
    msg[63] = MSG_SUFFIX_2;

    for (uint8_t i = 0; i < 64; i++)
    {
        while (!EUSART1_IsTxReady());
        EUSART1_Write(msg[i]);
    }
}

void SendFanSpeedToWiFi(uint8_t speed)
{
    uint8_t msg[64] = {0};

    msg[0] = MSG_PREFIX_1;
    msg[1] = MSG_PREFIX_2;
    msg[2] = HMI_ID;         // Source ID (HMI)
    msg[3] = 0x01;           // Destination ID (WiFi)
    msg[4] = 0x20;           // Fan Control message type
    msg[5] = 0x01;           // Fan ID
    msg[6] = 0x01;           // Status
    msg[7] = speed;          // Fan speed data
    msg[8] = speed;          // Fan speed set
    msg[62] = MSG_SUFFIX_1;
    msg[63] = MSG_SUFFIX_2;

    for (uint8_t i = 0; i < 64; i++)
    {
        while (!EUSART1_IsTxReady());
        EUSART1_Write(msg[i]);
    }
}

void CheckButtonAndSendFanSpeed(void)
{
    static bool button_pressed = false;
    static uint8_t fan_speed = 1;  // Start at 1 (avoid 0 if unused)

    // Check if the button is pressed (active low)
    if (IO_RC2_GetValue() == 1)
    {
        if (!button_pressed)
        {
            button_pressed = true;

            // Cycle through fan speeds: 1 → 2 → 3 → 1
            fan_speed = (fan_speed % 3) + 1;

            // Send the message to WiFi
            SendFanSpeedToWiFi(fan_speed);
        }
    }
    else
    {
        button_pressed = false;
    }
}

 void BlinkIO_RA7Twice(void)
{
    for (uint8_t i = 0; i < 2; i++)
    {
        IO_RA7_SetHigh(); // Turn on the pin
        __delay_ms(200);  // Keep it on for 200ms
        IO_RA7_SetLow();  // Turn off the pin
        __delay_ms(200);  // Keep it off for 200ms
    }
}

void BlinkIO_RB4Twice(void)
{
    for (uint8_t i = 0; i < 2; i++)
    {
        IO_RB4_SetHigh(); // Turn on the pin
        __delay_ms(200);  // Keep it on for 200ms
        IO_RB4_SetLow();  // Turn off the pin
        __delay_ms(200);  // Keep it off for 200ms
    }
}

void BlinkIO_RB3Twice(void)
{
    for (uint8_t i = 0; i < 2; i++)
    {
        IO_RB3_SetHigh(); // Turn on the pin
        __delay_ms(200);  // Keep it on for 200ms
        IO_RB3_SetLow();  // Turn off the pin
        __delay_ms(200);  // Keep it off for 200ms
    }
}

void BlinkIO_RC0Twice(void)
{
    for (uint8_t i = 0; i < 2; i++)
    {
        IO_RC0_SetHigh(); // Turn on the pin
        __delay_ms(200);  // Keep it on for 200ms
        IO_RC0_SetLow();  // Turn off the pin
        __delay_ms(200);  // Keep it off for 200ms
    }
}

void main(void)
{
    SYSTEM_Initialize();
    INTERRUPT_GlobalInterruptEnable();
    INTERRUPT_PeripheralInterruptEnable();

    while (1)
    {
        // Check if data is available in the UART receive buffer
        if (EUSART1_IsRxReady())
        {
            uint8_t rxData = EUSART1_Read();
            UART1_ISRHandler(rxData); // Call the handler manually with the received data
        }

        if (message_ready)
        {
            ProcessMessage((const uint8_t*)uart_buffer); // Cast to const uint8_t*
            message_ready = false; // Reset the flag
        }

        // Check the button and send fan speed messages
        CheckButtonAndSendFanSpeed();

        // MCU can now sleep or do other work without blocking!
    }
}
